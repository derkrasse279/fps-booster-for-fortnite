import os
import time
import shutil

# ✅ Passwort für den Zugriff
PASSWORT = "360 fps+"

def passwort_abfrage():
    versuche = 3
    while versuche > 0:
        eingabe = input("\n🔑 Passwort eingeben: ")
        if eingabe == PASSWORT:
            print("\n✅ Passwort korrekt! Zugang gewährt.\n")
            return True
        else:
            versuche -= 1
            print(f"❌ Ein Satz mit X, das war wohl nix! ({versuche} Versuche übrig)")
    
    print("\n🚫 Zu viele falsche Versuche. Programm wird beendet!")
    exit()

def start():
    print("\n🔹 Programm wird gestartet...")
    time.sleep(1)
    print("✅ Programm läuft!")

def stop():
    print("\n🛑 Programm wird gestoppt...")
    time.sleep(1)
    print("✅ Programm wurde beendet.")
    exit()

def energiesparmodus():
    print("\n🌱 Energiesparmodus wird aktiviert...")
    os.system("powercfg /s SCHEME_BALANCED")  # Energiesparmodus aktivieren
    time.sleep(1)
    print("✅ Energiesparmodus aktiviert!")

def energiesparmodus_deaktivieren():
    print("\n⚡ Energiesparmodus wird deaktiviert, Höchstleistung wird aktiviert...")
    os.system("powercfg /s SCHEME_MAX")  # Höchstleistung aktivieren
    time.sleep(1)
    print("✅ Höchstleistungsmodus aktiviert!")

def temp_files_löschen():
    temp_folders = [os.getenv("TEMP"), os.getenv("TMP")]
    files_deleted = 0
    for folder in temp_folders:
        if folder and os.path.exists(folder):
            for file in os.listdir(folder):
                file_path = os.path.join(folder, file)
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        files_deleted += 1
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                        files_deleted += 1
                except Exception:
                    continue
    print(f"🗑️ {files_deleted} temporäre Dateien gelöscht!")

def hintergrundprozesse_deaktivieren():
    print("\n🛑 Deaktiviere unnötige Hintergrundprozesse...")
    services = ["SysMain", "DiagTrack", "WSearch"]
    for service in services:
        os.system(f"sc config {service} start= disabled")
        os.system(f"sc stop {service}")
    print("✅ Hintergrundprozesse deaktiviert!")

def fortnite_optimieren():
    print("\n🎮 Fortnite wird optimiert...")
    os.system("bcdedit /set useplatformclock false")
    os.system("bcdedit /set disabledynamictick yes")
    os.system("bcdedit /set tscsyncpolicy Enhanced")
    print("✅ Fortnite-Optimierung abgeschlossen!")

def show_menu():
    while True:
        print("\n🔧 **Menü**")
        print("1️⃣ Start")
        print("2️⃣ Stop")
        print("3️⃣ Energiesparmodus aktivieren")
        print("4️⃣ Energiesparmodus deaktivieren")
        print("5️⃣ Temporäre Dateien löschen")
        print("6️⃣ Hintergrundprozesse deaktivieren")
        print("7️⃣ Fortnite optimieren")
        print("8️⃣ Beenden")
        
        choice = input("\n👉 Wähle eine Option: ")

        if choice == "1":
            start()
        elif choice == "2":
            stop()
        elif choice == "3":
            energiesparmodus()
        elif choice == "4":
            energiesparmodus_deaktivieren()
        elif choice == "5":
            temp_files_löschen()
        elif choice == "6":
            hintergrundprozesse_deaktivieren()
        elif choice == "7":
            fortnite_optimieren()
        elif choice == "8":
            print("👋 Beende das Menü...")
            break
        else:
            print("⚠️ Ungültige Eingabe! Bitte wähle eine Zahl zwischen 1 und 8.")

if __name__ == "__main__":
    if passwort_abfrage():  # Starte das Menü nur, wenn das Passwort korrekt ist
        show_menu()
